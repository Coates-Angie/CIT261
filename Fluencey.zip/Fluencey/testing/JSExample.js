//variable example
var turtle = "red";
document.write(turtle);

//if statement
var myNum1 = 7;
var myNum2 = 10;
if (myNum1 < myNum2) {
    alert("Number is less than 10.");


//Switch Statement
var day = 3;
switch (day) {
    case 1:
        document.write("Monday");
        break;
    case 2:
        document.write("Tuesday");
        break;
    case 3:
        document.write("Wednesday");
        break;
    default:
        document.write("Another day");
}

//for Loop Example
var i = 0;
for (; i < 10; ) {
    document.write(i);
    i++;
}

//While loop
var i=0;
while (i<=10) {
document.write(i + "<br />");
    i++;
}

// do While
var i = 20;
do {
    document.write(i + "<br />");
    i++;
}
while (i <= 25);
